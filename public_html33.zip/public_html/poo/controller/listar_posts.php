<?php
require('../model/class_post.php');

 // echo listar_posts();
    $Post=new Post();
	$Post->ListarPosts();