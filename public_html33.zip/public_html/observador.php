<?php
if(!isset($_SESSION)){
    
    header('Location:index.html#openModal');
    
}