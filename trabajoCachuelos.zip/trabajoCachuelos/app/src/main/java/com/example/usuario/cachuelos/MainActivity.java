package com.example.usuario.cachuelos;

import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.example.usuario.cachuelos.Adaptador.Adaptador;
import com.example.usuario.cachuelos.Moldes.Post;
import com.example.usuario.cachuelos.Moldes.User;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.DataOutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Scanner;



public class MainActivity extends AppCompatActivity {

    EditText etEmail,etPassword;
    //controlador
     boolean permitir = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        etEmail=findViewById(R.id.etEmail);
        etPassword=findViewById(R.id.etPassword);





    }



    //AsyncTask


    class PeticionAT extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... param) {

            return requestGet(param[0],param[1]);
        }

        @Override
        protected void onPostExecute(String res) {

            boolean r = objJSON(res);
            if(r){
                if(r){
                    if(permitir) {

                        Intent i = new Intent(getApplicationContext(), Principal.class);
                        startActivity(i);

                        Toast.makeText(getApplicationContext(),"datos concuerdan" ,
                                Toast.LENGTH_SHORT).show();

                    }else{

                        Toast.makeText(getApplicationContext(),"datos erroneos",
                                Toast.LENGTH_SHORT).show();

                    }
                }
                else{
                    Toast.makeText(getApplicationContext(),"Error en conexión",
                            Toast.LENGTH_SHORT).show();
                }
            }

        }

    }



    //fin AsyncTask


    //Conexion

    public String requestGet(String email, String password){



        String parametros = "email="+email+"&pass="+password;
        HttpURLConnection conexion = null;
        String rspta = "";

        try{

            URL url = new URL("http://cachuelos.000webhostapp.com/login_android.php");
            conexion = (HttpURLConnection) url.openConnection();


            conexion.setRequestMethod("POST");
            conexion.setRequestProperty("Content-Length",
                    Integer.toString(parametros.getBytes().length));


            DataOutputStream wr = new DataOutputStream(conexion.getOutputStream());
            wr.writeBytes(parametros);
            wr.close();


            Scanner inStream = new Scanner(conexion.getInputStream());
            while(inStream.hasNextLine())
                rspta = rspta + inStream.nextLine();

        }catch (Exception e){}

        return rspta;
    }


    //fin Conexion


    //JSON

    public boolean objJSON(String respuesta){
        boolean res = false;

        try{
            JSONArray json = new JSONArray(respuesta);

            if(json.length()>0){
                res = true;
            }

            // Decodificar el json
            for(int i=0; i<json.length(); i++){
                JSONObject jsonObject = json.getJSONObject(i);

                User us = new User();

                us.setEmail(jsonObject.getString("email"));
                us.setPassword(jsonObject.getString("pass"));

                permitir = (Boolean)jsonObject.getBoolean("stat");







            }

        }catch (Exception e){}

        return res;
    }



    //fin JSON





    public void Ingresar(View view){
/*
        String email= etEmail.getText().toString();
        String pass= etPassword.getText().toString();
*/
        Intent i = new Intent(getApplicationContext(), Principal.class);
        startActivity(i);

/*
        if(email.isEmpty()&&pass.isEmpty()){

            Toast.makeText(this,"No dejar espacios en blanco",Toast.LENGTH_LONG).show();

        }else {


            new PeticionAT().execute(email,pass);

        }
*/

    }
    public void Registrar(View view){

        Intent i = new Intent(this,RegistarActivity.class);
        startActivity(i);

    }
}
