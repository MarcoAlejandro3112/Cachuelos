package com.example.usuario.cachuelos.Adaptador;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.example.usuario.cachuelos.Moldes.Post;
import com.example.usuario.cachuelos.R;

import java.util.List;

public class Adaptador extends BaseAdapter {

    private Context mContext;
    private List<Post> mPostList;

    //constructor


    public Adaptador(Context mContext, List<Post> mPostList) {
        this.mContext = mContext;
        this.mPostList = mPostList;
    }

    @Override
    public int getCount() {
        return mPostList.size();
    }

    @Override
    public Object getItem(int i) {
        return mPostList.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {

        View v = View.inflate(mContext,R.layout.item,null );

        TextView Titulo = (TextView) v.findViewById(R.id.tvTitulo);
        TextView Fecha = (TextView) v.findViewById(R.id.tvFecha);
        TextView Correo = (TextView) v.findViewById(R.id.tvCorreo);
        TextView Cont = (TextView) v.findViewById(R.id.tvCont);
        TextView Oferta = (TextView) v.findViewById(R.id.tvOferta);
        TextView Postulantes = (TextView) v.findViewById(R.id.tvPostulantes);


        Titulo.setText(mPostList.get(i).getTitulo());
        Fecha.setText(mPostList.get(i).getFecha());
        Correo.setText(mPostList.get(i).getCorreo());
        Cont.setText(mPostList.get(i).getCont());
        Oferta.setText(String.valueOf(mPostList.get(i).getOferta()));
        Postulantes.setText(String.valueOf(mPostList.get(i).getPostulantes()));


        v.setTag(mPostList.get(i).getId());


        return v;
    }
}
