package com.example.usuario.cachuelos;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class Detalle extends AppCompatActivity {

    TextView tvTitulo,tvCorreo,tvFecha,tvCont,tvOferta;

    String titulo,fecha,correo,cont;
    int oferta;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalle);

        tvCont=findViewById(R.id.tvCont);
        tvCorreo=findViewById(R.id.tvCorreo);
        tvFecha=findViewById(R.id.tvFecha);
        tvOferta=findViewById(R.id.tvOfertad);
        tvTitulo=findViewById(R.id.tvTitulo);

        titulo=getIntent().getExtras().getString("titulo");
        cont=getIntent().getExtras().getString("cont");
        correo=getIntent().getExtras().getString("correo");
        fecha=getIntent().getExtras().getString("fecha");
        oferta=getIntent().getExtras().getInt("oferta");




        tvTitulo.setText(titulo);
        tvOferta.setText(""+oferta);
        tvFecha.setText(fecha);
        tvCorreo.setText(correo);
        tvCont.setText(cont);

    }
}
