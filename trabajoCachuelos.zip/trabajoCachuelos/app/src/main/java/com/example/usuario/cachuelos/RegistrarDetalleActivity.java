package com.example.usuario.cachuelos;

import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.DataOutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Scanner;

public class RegistrarDetalleActivity extends AppCompatActivity {

EditText etNombre,etApellido,etDNI,etTelefono,etDescripcion;
Spinner spPais,spPerfil;
Boolean controlador=false;

ArrayList<String> pais;
ArrayList<String> perfil;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registrar_detalle);

        etApellido=findViewById(R.id.etApellido);
        etDescripcion=findViewById(R.id.etDescripcion);
        etDNI=findViewById(R.id.etDNI);
        etNombre=findViewById(R.id.etNombre);
        etTelefono=findViewById(R.id.etTelefono);

        spPais=findViewById(R.id.spPais);
        spPerfil=findViewById(R.id.spPerfil);

//spinner perfil
        perfil = new ArrayList<String>();

        perfil.add(new String("Trabajador"));
        perfil.add(new String("Empleador"));

        ArrayAdapter adaptador = new ArrayAdapter(this,
                android.R.layout.simple_list_item_1,perfil);

        spPerfil.setAdapter(adaptador);
//finspinner perfil

//spinner pais

        pais = new ArrayList<String>();

        pais.add(new String("Perú"));
        pais.add(new String("Afganistán"));
        pais.add(new String("Albania"));
        pais.add(new String("Alemania"));
        pais.add(new String("Ecuador"));
        pais.add(new String("Brasil"));
        pais.add(new String("chile"));
        pais.add(new String("mexico"));
        pais.add(new String("E.E.U.U"));
        pais.add(new String("Rusia"));
        pais.add(new String("China"));









        ArrayAdapter adaptador2 = new ArrayAdapter(this,
                android.R.layout.simple_list_item_1,pais);

        spPais.setAdapter(adaptador2);

//fin spinner pais

    }



    //AsyncTask


    class PeticionAT extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... param) {

            return requestGet(param[0],param[1]);
        }

        @Override
        protected void onPostExecute(String res) {

            boolean r = objJSON(res);
            if(r){
                if(r){
                    if(controlador){

                        Intent i = new Intent(getApplicationContext(),MainActivity.class);
                        startActivity(i);

                    }else{

                        Toast.makeText(getApplicationContext(),"Fallo al Guardar",
                                Toast.LENGTH_SHORT).show();


                    }

                }
                else{
                    Toast.makeText(getApplicationContext(),"Fallo al cargar",
                            Toast.LENGTH_SHORT).show();
                }
            }

        }

    }



    //fin AsyncTask


    //Conexion

    public String requestGet(String email, String password){



        String parametros = "email="+email+"&pass="+password;//falat poner parametros
        HttpURLConnection conexion = null;
        String rspta = "";

        try{

            URL url = new URL("http://cachuelos.000webhostapp.com/register.php");//falta poner el url adecuado
            conexion = (HttpURLConnection) url.openConnection();


            conexion.setRequestMethod("POST");
            conexion.setRequestProperty("Content-Length",
                    Integer.toString(parametros.getBytes().length));


            DataOutputStream wr = new DataOutputStream(conexion.getOutputStream());
            wr.writeBytes(parametros);
            wr.close();


            Scanner inStream = new Scanner(conexion.getInputStream());
            while(inStream.hasNextLine())
                rspta = rspta + inStream.nextLine();

        }catch (Exception e){}

        return rspta;
    }


    //fin Conexion


    //JSON

    public boolean objJSON(String respuesta){
        boolean res = false;

        try{
            JSONArray json = new JSONArray(respuesta);

            if(json.length()>0){
                res = true;
            }

            // Decodificar el json
            for(int i=0; i<json.length(); i++){
                JSONObject jsonObject = json.getJSONObject(i);

                controlador=(boolean)jsonObject.getBoolean("stat");


            }

        }catch (Exception e){}

        return res;
    }



    //fin JSON


    public void Guardar(View view){


        Intent i = new Intent(this,Principal.class);
        startActivity(i);

   //PeticionAT.execute();

    }


}
