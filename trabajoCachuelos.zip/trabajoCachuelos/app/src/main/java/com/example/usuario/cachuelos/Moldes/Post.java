package com.example.usuario.cachuelos.Moldes;

public class Post {

    int Id,Postulantes,Oferta;
    String Titulo,Fecha,Correo,Cont;


    public Post(int id, String titulo, String fecha, String correo, String cont, int oferta, int postulantes) {
        Id = id;
        Titulo = titulo;
        Fecha = fecha;
        Correo = correo;
        Cont = cont;
        Postulantes = postulantes;
        Oferta = oferta;
    }

    public Post() {

    }

    public int getId() {
        return Id;
    }

    public void setId(int id) {
        Id = id;
    }

    public String getTitulo() {
        return Titulo;
    }

    public void setTitulo(String titulo) {
        Titulo = titulo;
    }

    public String getFecha() {
        return Fecha;
    }

    public void setFecha(String fecha) {
        Fecha = fecha;
    }

    public String getCorreo() {
        return Correo;
    }

    public void setCorreo(String correo) {
        Correo = correo;
    }

    public String getCont() {
        return Cont;
    }

    public void setCont(String cont) {
        Cont = cont;
    }

    public int getPostulantes() {
        return Postulantes;
    }

    public void setPostulantes(int postulantes) {
        Postulantes = postulantes;
    }

    public int getOferta() {
        return Oferta;
    }

    public void setOferta(int oferta) {
        Oferta = oferta;
    }
}
