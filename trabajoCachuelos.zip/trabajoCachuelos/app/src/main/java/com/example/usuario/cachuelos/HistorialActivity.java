package com.example.usuario.cachuelos;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;

public class HistorialActivity extends AppCompatActivity {
ListView lvTrabajos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_historial);

        lvTrabajos=findViewById(R.id.lvTrabajos);



    }
}
