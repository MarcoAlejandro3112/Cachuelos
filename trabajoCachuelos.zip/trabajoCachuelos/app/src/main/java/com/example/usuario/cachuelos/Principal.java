package com.example.usuario.cachuelos;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;


import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.example.usuario.cachuelos.Adaptador.Adaptador;
import com.example.usuario.cachuelos.Moldes.Post;

import org.json.JSONArray;
import org.json.JSONObject;

import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Principal extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {

    ListView lvTrabajo;
    Adaptador adaptador;
    List<Post> mListPost;

    String titulo,fecha,correo,cont;
    int oferta;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_principal);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);


        lvTrabajo=findViewById(R.id.lvTrabajos);


        mListPost=new ArrayList();


        //prueba
        Post p = new Post(1,"trabajo 1","22/11/18","s@gmail.com","Lorem ipsum dolor sit amet, consectetur "
               ,150,12);
        Post p1 = new Post(2,"trabajo 2 ","22/11/18","g@gmail.xom","Lorem ipsum dolor sit amet, consectetur" +
                "Lorem ipsum dolor sit amet, consectetur" +
                "Lorem ipsum dolor sit amet, consectetur" +
                "Lorem ipsum dolor sit amet, consectetur",25,13);
        Post p2 = new Post(3,"trabajo 3","22/11/18","j@gmail.xom","Lorem ipsum dolor sit amet," +
                "Lorem ipsum dolor sit amet, consectetur" +
                "Lorem ipsum dolor sit amet, consectetur consectetur",15,14);
        Post p3 = new Post(4,"trabajo 5","22/11/18","r@gmail.xom","Lorem ipsum dolor sit amet," +
                "Lorem ipsum dolor sit amet, consectetur" +
                "Lorem ipsum dolor sit amet, consectetur consectetur",60,15);

        mListPost.add(p);
        mListPost.add(p2);
        mListPost.add(p3);
        mListPost.add(p1);

        adaptador = new Adaptador(getApplicationContext(),mListPost);
        lvTrabajo.setAdapter(adaptador);

        //fin prueba


        lvTrabajo.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                Intent i = new Intent(getApplicationContext(),Detalle.class);

                Post po = mListPost.get(position);

                titulo= po.getTitulo();
                fecha= po.getFecha();
                cont= po.getCont();
                correo= po.getCorreo();
                oferta= po.getOferta();



                i.putExtra("titulo",titulo);
                i.putExtra("fecha",fecha);
                i.putExtra("cont",cont);
                i.putExtra("oferta",oferta);
                i.putExtra("correo",correo);

                startActivity(i);

            }
        });







        //AsyncTask
        new PeticionAT().execute();






        //boton flotante
        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                Intent i = new Intent(getApplicationContext(),PublicarActivity.class);
                startActivity(i);

            }
        });

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);


    }

     //fin boton flotante


    //AsyncTask


    class PeticionAT extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... param) {

            return requestGet();
        }

        @Override
        protected void onPostExecute(String res) {

            boolean r = objJSON(res);
            if(r){
                if(r){




                    adaptador = new Adaptador(getApplicationContext(),mListPost);
                    lvTrabajo.setAdapter(adaptador);


                }
                else{
                    Toast.makeText(getApplicationContext(),"Fallo al cargar",
                            Toast.LENGTH_SHORT).show();
                }
            }

        }

    }



    //fin AsyncTask


    //Conexion

    public String requestGet(){

        HttpURLConnection conexion = null;
        String rspta = "";

        try{

            URL url = new URL("http://cachuelos.000webhostapp.com/listar_posts.php");
            conexion = (HttpURLConnection) url.openConnection();


            conexion.setRequestMethod("GET");
            conexion.connect();


            Scanner inStream = new Scanner(conexion.getInputStream());
            while(inStream.hasNextLine())
                rspta = rspta + inStream.nextLine();

        }catch (Exception e){}

        return rspta;
    }


    //fin Conexion


    //JSON

    public boolean objJSON(String respuesta){
        boolean res = false;

        try{
            JSONArray json = new JSONArray(respuesta);

            if(json.length()>0){
                res = true;
            }

            // Decodificar el json
            for(int i=0; i<json.length(); i++){
                JSONObject jsonObject = json.getJSONObject(i);

                Post po = new Post();

                po.setTitulo(jsonObject.getString("title"));
                po.setCorreo(jsonObject.getString("user"));
                po.setFecha(jsonObject.getString("date"));
                po.setCont(jsonObject.getString("content"));
                po.setPostulantes(10);
                po.setOferta(Integer.parseInt(jsonObject.getString("payment")));



                mListPost.add(po);




            }

        }catch (Exception e){}

        return res;
    }



    //fin JSON











    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.principal, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_actualizar) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_Historial) {

            Intent i = new Intent(this,HistorialActivity.class);
            startActivity(i);

        }  else if (id == R.id.nav_Ajustes) {

        } else if (id == R.id.nav_Salir) {

        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
}
