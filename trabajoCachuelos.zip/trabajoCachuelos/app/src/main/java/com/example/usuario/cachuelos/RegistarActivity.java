package com.example.usuario.cachuelos;

import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;




import org.json.JSONArray;
import org.json.JSONObject;

import java.io.DataOutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Scanner;

public class RegistarActivity extends AppCompatActivity {
    EditText etEmailR, etPasswordR, etConPasR;

    Boolean controlador=false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registar);

        etEmailR = findViewById(R.id.etEmailR);
        etPasswordR = findViewById(R.id.etPasswordR);
        etConPasR = findViewById(R.id.etConfPassR);





    }


    //AsyncTask


    class PeticionAT extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... param) {

            return requestGet(param[0],param[1]);
        }

        @Override
        protected void onPostExecute(String res) {

            boolean r = objJSON(res);
            if(r){
                if(r){
                  if(controlador){

                      Intent i = new Intent(getApplicationContext(),RegistrarDetalleActivity.class);
                      startActivity(i);

                  }else{

                      Toast.makeText(getApplicationContext(),"Fallo al Guardar",
                              Toast.LENGTH_SHORT).show();


                  }

                }
                else{
                    Toast.makeText(getApplicationContext(),"Fallo al cargar",
                            Toast.LENGTH_SHORT).show();
                }
            }

        }

    }



    //fin AsyncTask


    //Conexion

    public String requestGet(String email, String password){



        String parametros = "email="+email+"&pass="+password;
        HttpURLConnection conexion = null;
        String rspta = "";

        try{

            URL url = new URL("http://cachuelos.000webhostapp.com/register.php");//falta poner el url adecuado
            conexion = (HttpURLConnection) url.openConnection();


            conexion.setRequestMethod("POST");
            conexion.setRequestProperty("Content-Length",
                    Integer.toString(parametros.getBytes().length));


            DataOutputStream wr = new DataOutputStream(conexion.getOutputStream());
            wr.writeBytes(parametros);
            wr.close();


            Scanner inStream = new Scanner(conexion.getInputStream());
            while(inStream.hasNextLine())
                rspta = rspta + inStream.nextLine();

        }catch (Exception e){}

        return rspta;
    }


    //fin Conexion


    //JSON

    public boolean objJSON(String respuesta){
        boolean res = false;

        try{
            JSONArray json = new JSONArray(respuesta);

            if(json.length()>0){
                res = true;
            }

            // Decodificar el json
            for(int i=0; i<json.length(); i++){
                JSONObject jsonObject = json.getJSONObject(i);

               controlador=(boolean)jsonObject.getBoolean("stat");


            }

        }catch (Exception e){}

        return res;
    }



    //fin JSON


    public void Siguiente(View view){


        String email=etEmailR.getText().toString();
        String password=etPasswordR.getText().toString();
        String confpass=etConPasR.getText().toString();


        if(email==null&&password==null&&confpass==null){

            Toast.makeText(getApplicationContext(),"No dejes espacios sin rellenar",
                    Toast.LENGTH_SHORT).show();


        }else{




            if(password==confpass) {

                new PeticionAT().execute(email, password, confpass);

            }else{

                Toast.makeText(getApplicationContext(),"Contraseñas no coinciden",
                        Toast.LENGTH_SHORT).show();

            }

        }

    }








}
