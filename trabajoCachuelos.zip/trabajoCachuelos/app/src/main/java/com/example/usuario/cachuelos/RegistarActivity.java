package com.example.usuario.cachuelos;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class RegistarActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registar);
    }
}
